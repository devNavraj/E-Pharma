export default {
    products:[
        {
            _id: '1',
            name: 'Mupirocin',
            category: 'Antibiotic',
            image: '/images/d1.jpg',
            price: 145,
            manufacturer: 'Arya',
            rating: 4.5,
            numReviews: 10
        },
        {
            _id: '2',
            name: 'Lotrimin Ultra',
            category: 'Antifungal',
            image: '/images/d2.jpg',
            price: 100,
            manufacturer: 'Nepal Pharmaceutical',
            rating: 4.7,
            numReviews: 15
        },
        {
            _id: '3',
            name: 'Nims',
            category: 'Paracetamol',
            image: '/images/d3.jpg',
            price: 25,
            manufacturer: 'Arya',
            rating: 4.2,
            numReviews: 20 
        }
]
}